/**
 * Sidenote Block - Editor Component
 * True margin note - no marker configuration, auto-numbered
 */
(function(wp) {
    const { registerBlockType } = wp.blocks;
    const { useBlockProps, RichText } = wp.blockEditor;
    const { __ } = wp.i18n;
    const el = wp.element.createElement;

    registerBlockType('kunaal/sidenote', {
        edit: function(props) {
            const { attributes, setAttributes } = props;
            const { content } = attributes;
            
            const blockProps = useBlockProps({
                className: 'sidenote-editor-wrapper'
            });

            return el(
                'span',
                blockProps,
                // Reference marker preview
                el('sup', { className: 'sidenote-ref-preview' }, '•'),
                // Sidenote content in margin preview
                el(
                    'span',
                    { className: 'sidenote-content-preview' },
                    el(RichText, {
                        tagName: 'span',
                        value: content,
                        onChange: function(value) { setAttributes({ content: value }); },
                        placeholder: __('Margin note...', 'kunaal-theme'),
                        allowedFormats: ['core/bold', 'core/italic', 'core/link']
                    })
                )
            );
        },
        save: function() {
            return null; // Dynamic block
        }
    });
})(window.wp);
