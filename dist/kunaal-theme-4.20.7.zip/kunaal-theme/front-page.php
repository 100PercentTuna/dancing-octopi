<?php
/**
 * Front Page Template
 *
 * @package Kunaal_Theme
 */

get_header();
get_template_part('template-parts/home');

get_footer();
